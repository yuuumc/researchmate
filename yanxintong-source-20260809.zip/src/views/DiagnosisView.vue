<script setup>
import { computed } from 'vue'
import { useRouter } from 'vue-router'
import { useProfileStore } from '@/stores/profile'
import { useDiagnosisStore } from '@/stores/diagnosis'
import { buildDiagnosisInput } from '@/utils/diagnosisInput'
import DiagnosisReport from '@/components/DiagnosisReport.vue'
import { SEED_DIAGNOSIS_REPORT, SEED_ABILITY_STARS } from '@/data/seedDemo'

const router = useRouter()
const profileStore = useProfileStore()
const diagnosisStore = useDiagnosisStore()

// ========== v3.1.1: Agent API 结果 ==========
const hasApiResult = computed(() => !!diagnosisStore.lastReport?.structured)
const apiData = computed(() => diagnosisStore.lastReport?.structured || {})
const loading = computed(() => diagnosisStore.loading)
const error = computed(() => diagnosisStore.error)

// 能力星图：API ability_stars 优先 → profileStore → 种子
const abilityStars = computed(() => {
  // API 返回 { topic: star } 对象
  const apiStars = apiData.value.ability_stars
  if (apiStars && typeof apiStars === 'object' && Object.keys(apiStars).length >= 3) {
    return Object.entries(apiStars).map(([topic, star]) => ({
      topic,
      star,
      score: star * 20,
      type: star <= 2 ? 'weak' : 'strength'
    }))
  }
  const stars = profileStore.profile?.ability_stars
  if (stars && Object.keys(stars).length >= 3) {
    return Object.entries(stars).map(([topic, star]) => {
      const isWeak = star <= 2
      const score = profileStore.profile?.subject_scores?.find((s) => s.subject === topic)?.score
      return {
        topic,
        star,
        score: typeof score === 'number' ? score : star * 20,
        type: isWeak ? 'weak' : 'strength'
      }
    })
  }
  return SEED_ABILITY_STARS
})

const strengths = computed(() => abilityStars.value.filter((a) => a.type === 'strength').slice(0, 3))
const weakPoints = computed(() => abilityStars.value.filter((a) => a.type === 'weak').slice(0, 2))

// 诊断报告数据：API 8 字段优先，种子 fallback
const reportData = computed(() => {
  if (hasApiResult.value) {
    const s = apiData.value
    return {
      score: s.score ?? SEED_DIAGNOSIS_REPORT.score,
      subject: s.subject || SEED_DIAGNOSIS_REPORT.subject,
      weak_points: s.weak_points || [],
      direct_causes: s.direct_causes || [],
      middle_causes: s.middle_causes || [],
      root_causes: s.root_causes || [],
      remediation: s.remediation_path || ''
    }
  }
  return SEED_DIAGNOSIS_REPORT
})

// 能力总评：API overall_level 优先，否则从星图均值计算
const overallLevel = computed(() => {
  if (apiData.value.overall_level != null) return apiData.value.overall_level
  const avg = abilityStars.value.reduce((s, a) => s + a.star, 0) / (abilityStars.value.length || 1)
  return Math.round((avg / 5) * 100)
})

// 诊断理由（v3.1.1 新增字段）
const diagnosisReason = computed(() => apiData.value.diagnosis_reason || '')

// 发起诊断
async function generateDiagnosis() {
  try {
    await diagnosisStore.runDiagnosis(buildDiagnosisInput())
  } catch {
    // error 已在 store 中设置
  }
}

function goChat() {
  router.push({ path: '/chat', query: { agent: 'diagnose' } })
}

// P0 #8: 诊断完成 → 引导进入旗舰旅程下一步（规划）
function goJourney() {
  router.push('/journey')
}
</script>

<template>
  <div class="diagnosis-view">
    <div class="page-content">
      <!-- 页头 -->
      <div class="page-header">
        <div class="page-eyebrow"><span class="dot"></span><span>Diagnosis Agent</span></div>
        <h1 class="page-title">成长诊断</h1>
        <p class="page-subtitle">4 层根因链 · 能力星图 · 精准定位薄弱环节</p>
      </div>

      <!-- 生成诊断入口 -->
      <section class="generate-section">
        <button
          class="generate-btn"
          :disabled="loading"
          @click="generateDiagnosis"
        >
          <span v-if="loading" class="generate-spinner"></span>
          <span>{{ loading ? 'AI 诊断中…' : hasApiResult ? '重新生成诊断报告' : '生成个性化诊断报告' }}</span>
        </button>
        <span class="generate-hint" v-if="!hasApiResult && !loading">
          基于你的知识图谱与学习画像，由 AI 生成 8 字段结构化诊断
        </span>
        <span class="generate-hint" v-else-if="hasApiResult">
          已接入真实 AI 诊断链路 · 8 字段结构化输出
        </span>
        <div v-if="error" class="generate-error">
          诊断生成失败：{{ error }}
        </div>
      </section>

      <!-- 顶部概览：总分 + 能力等级 -->
      <section class="overview-row">
        <div class="overview-card overview-card--score">
          <div class="ov-label">
            LAST DIAGNOSIS
            <span v-if="hasApiResult" class="api-badge">AI</span>
          </div>
          <div class="ov-score">
            <span class="ov-num">{{ reportData.score }}</span><span class="ov-unit">分</span>
          </div>
          <div class="ov-bar">
            <div class="ov-fill" :style="{ width: (reportData.score / 1.5) + '%' }"></div>
          </div>
        </div>
        <div class="overview-card overview-card--level">
          <div class="ov-label">ABILITY LEVEL</div>
          <div class="ov-score">
            <span class="ov-num">{{ overallLevel }}</span><span class="ov-unit">%</span>
          </div>
          <div class="ov-hint">{{ strengths.length }} 优势 · {{ weakPoints.length }} 薄弱</div>
        </div>
        <div class="overview-card overview-card--subject">
          <div class="ov-label">SUBJECT</div>
          <div class="ov-subject">{{ reportData.subject }}</div>
        </div>
      </section>

      <!-- 能力星图 -->
      <section class="section">
        <div class="section-head">
          <span class="section-icon">★</span>
          <span class="section-title">能力星图</span>
          <span class="section-en">Ability Radar</span>
        </div>
        <div class="ability-grid">
          <div
            v-for="a in abilityStars"
            :key="a.topic"
            class="ability-item"
            :class="{ 'ability-item--weak': a.type === 'weak' }"
          >
            <div class="ability-top">
              <span class="ability-topic">{{ a.topic }}</span>
              <span class="ability-score">{{ a.score }}分</span>
            </div>
            <div class="ability-stars">
              <span
                v-for="n in 5"
                :key="n"
                class="star"
                :class="{ filled: n <= a.star }"
              >★</span>
            </div>
            <div class="ability-bar">
              <div class="ability-bar-fill" :style="{ width: (a.score) + '%' }"></div>
            </div>
            <span class="ability-tag" :class="a.type === 'weak' ? 'tag-weak' : 'tag-strong'">
              {{ a.type === 'weak' ? '薄弱' : '优势' }}
            </span>
          </div>
        </div>
      </section>

      <!-- 优势 / 薄弱点 双栏 -->
      <section class="duo-section">
        <div class="duo-card duo-card--strength">
          <div class="duo-head">
            <span class="duo-icon">▲</span>
            <span class="duo-title">优势项</span>
            <span class="duo-en">Strengths</span>
          </div>
          <ul class="duo-list">
            <li v-for="s in strengths" :key="s.topic">
              <span class="duo-name">{{ s.topic }}</span>
              <span class="duo-meta">{{ s.star }}★ · {{ s.score }}分</span>
            </li>
          </ul>
        </div>
        <div class="duo-card duo-card--weak">
          <div class="duo-head">
            <span class="duo-icon">▼</span>
            <span class="duo-title">薄弱点</span>
            <span class="duo-en">Weak Points</span>
          </div>
          <ul class="duo-list">
            <li v-for="w in weakPoints" :key="w.topic">
              <span class="duo-name">{{ w.topic }}</span>
              <span class="duo-meta">{{ w.star }}★ · {{ w.score }}分</span>
            </li>
          </ul>
        </div>
      </section>

      <!-- 诊断结论：4 层根因链（复用 DiagnosisReport） -->
      <section class="section">
        <div class="section-head">
          <span class="section-icon">◈</span>
          <span class="section-title">诊断结论 · 4 层根因链</span>
          <span class="section-en">Root Cause Chain</span>
        </div>
        <DiagnosisReport :report="reportData" />
      </section>

      <!-- 诊断理由（v3.1.1 新增字段） -->
      <section v-if="diagnosisReason" class="section">
        <div class="section-head">
          <span class="section-icon">◉</span>
          <span class="section-title">诊断理由</span>
          <span class="section-en">Diagnosis Reason</span>
        </div>
        <div class="reason-card">
          <p class="reason-text">{{ diagnosisReason }}</p>
        </div>
      </section>

      <!-- 进对话入口 -->
      <section class="cta-section">
        <div class="cta-text">
          <span class="cta-title">需要深入诊断某个薄弱点？</span>
          <span class="cta-sub">进入与 Diagnosis Agent 的对话，获取针对性追问与即时讲解</span>
        </div>
        <button class="cta-btn" @click="goChat">
          <span>与诊断导师对话</span>
          <span class="cta-arrow">→</span>
        </button>
      </section>

      <!-- P0 #8: 诊断完成 → 引导进入旗舰旅程（规划步） -->
      <section v-if="hasApiResult" class="journey-cta-section">
        <div class="journey-cta-content">
          <span class="journey-cta-badge">Flagship Journey</span>
          <span class="journey-cta-title">基于诊断结果生成个性化规划</span>
          <span class="journey-cta-desc">进入旗舰旅程，诊断 → 规划 → 科研三步接力</span>
        </div>
        <button class="journey-cta-btn" @click="goJourney">
          <span>继续旗舰旅程</span>
          <span class="cta-arrow">→</span>
        </button>
      </section>
    </div>
  </div>
</template>

<style scoped>
.diagnosis-view {
  min-height: calc(100vh - 72px);
  background: var(--color-bg-base);
  padding: 32px 24px 64px;
}

.page-content {
  max-width: 880px;
  margin: 0 auto;
}

.page-header {
  margin-bottom: 28px;
}

.page-eyebrow {
  display: flex;
  align-items: center;
  gap: 6px;
  font-family: var(--font-mono);
  font-size: 11px;
  color: var(--color-fg-tertiary);
  letter-spacing: 1px;
  text-transform: uppercase;
  margin-bottom: 8px;
}

.page-eyebrow .dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #4d9de0;
}

.page-title {
  font-family: var(--font-serif);
  font-size: 28px;
  font-weight: 700;
  color: var(--color-ink-900);
  margin: 0;
}

.page-subtitle {
  font-size: 14px;
  color: var(--color-fg-secondary);
  margin: 6px 0 0;
}

/* === 生成诊断入口 === */
.generate-section {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
  margin-bottom: 28px;
  padding: 16px 20px;
  background: color-mix(in srgb, #4d9de0 5%, var(--color-bg-elevated));
  border: 1px dashed color-mix(in srgb, #4d9de0 30%, transparent);
  border-radius: var(--radius-lg);
}

.generate-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 22px;
  background: #4d9de0;
  color: #fff;
  border: none;
  border-radius: var(--radius-full);
  font-family: var(--font-serif);
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  white-space: nowrap;
}

.generate-btn:hover:not(:disabled) {
  background: #3a87c4;
  transform: translateY(-1px);
  box-shadow: 0 4px 12px color-mix(in srgb, #4d9de0 30%, transparent);
}

.generate-btn:disabled {
  opacity: 0.7;
  cursor: not-allowed;
}

.generate-spinner {
  width: 14px;
  height: 14px;
  border: 2px solid rgba(255,255,255,0.3);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.generate-hint {
  font-size: 12px;
  color: var(--color-fg-tertiary);
}

.generate-error {
  width: 100%;
  margin-top: 4px;
  padding: 8px 12px;
  background: color-mix(in srgb, #ff6b6b 10%, transparent);
  border: 1px solid color-mix(in srgb, #ff6b6b 30%, transparent);
  border-radius: var(--radius-sm);
  font-size: 12px;
  color: #d9483f;
}

.api-badge {
  display: inline-block;
  padding: 1px 6px;
  margin-left: 6px;
  background: linear-gradient(135deg, #4d9de0, #00d4aa);
  color: #fff;
  font-size: 9px;
  font-weight: 700;
  border-radius: var(--radius-full);
  letter-spacing: 0.5px;
  vertical-align: middle;
}

/* === 诊断理由 === */
.reason-card {
  background: var(--color-bg-elevated);
  border: 1px solid var(--color-border-subtle);
  border-left: 3px solid #4d9de0;
  border-radius: 0 var(--radius-md) var(--radius-md) 0;
  padding: 14px 18px;
}

.reason-text {
  font-size: 13px;
  color: var(--color-ink-700);
  line-height: 1.8;
  margin: 0;
}

/* === 概览行 === */
.overview-row {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  gap: 16px;
  margin-bottom: 32px;
}

.overview-card {
  background: var(--color-bg-elevated);
  border: 1px solid var(--color-border-subtle);
  border-radius: var(--radius-lg);
  padding: 18px 20px;
}

.ov-label {
  font-family: var(--font-mono);
  font-size: 10px;
  color: var(--color-fg-tertiary);
  letter-spacing: 1.5px;
  margin-bottom: 8px;
}

.ov-score {
  display: flex;
  align-items: baseline;
  gap: 4px;
}

.ov-num {
  font-family: var(--font-serif);
  font-size: 34px;
  font-weight: 700;
  color: var(--color-ink-900);
  line-height: 1;
}

.ov-unit {
  font-size: 14px;
  color: var(--color-fg-secondary);
}

.ov-bar {
  height: 4px;
  background: var(--color-bg-sunken);
  border-radius: var(--radius-full);
  overflow: hidden;
  margin-top: 10px;
}

.ov-fill {
  height: 100%;
  background: linear-gradient(90deg, #ff6b6b, #ffd166, #00d4aa);
  border-radius: var(--radius-full);
}

.ov-hint {
  font-size: 12px;
  color: var(--color-fg-tertiary);
  margin-top: 10px;
}

.ov-subject {
  font-family: var(--font-serif);
  font-size: 16px;
  font-weight: 600;
  color: var(--color-ink-900);
}

/* === 通用 section === */
.section {
  margin-bottom: 32px;
}

.section-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 16px;
}

.section-icon {
  color: #4d9de0;
  font-size: 14px;
}

.section-title {
  font-family: var(--font-serif);
  font-size: 15px;
  font-weight: 700;
  color: var(--color-ink-900);
}

.section-en {
  font-family: var(--font-mono);
  font-size: 10px;
  color: var(--color-fg-tertiary);
  text-transform: uppercase;
  letter-spacing: 1px;
}

/* === 能力星图 === */
.ability-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  gap: 14px;
}

.ability-item {
  position: relative;
  background: var(--color-bg-elevated);
  border: 1px solid var(--color-border-subtle);
  border-radius: var(--radius-md);
  padding: 14px 16px;
}

.ability-item--weak {
  border-color: color-mix(in srgb, #ff6b6b 40%, transparent);
}

.ability-top {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  margin-bottom: 6px;
}

.ability-topic {
  font-family: var(--font-serif);
  font-size: 14px;
  font-weight: 600;
  color: var(--color-ink-900);
}

.ability-score {
  font-family: var(--font-mono);
  font-size: 12px;
  color: var(--color-fg-secondary);
}

.ability-stars {
  display: flex;
  gap: 2px;
  margin-bottom: 8px;
}

.star {
  font-size: 14px;
  color: var(--color-border-default);
}

.star.filled {
  color: #ffd166;
}

.ability-bar {
  height: 4px;
  background: var(--color-bg-sunken);
  border-radius: var(--radius-full);
  overflow: hidden;
}

.ability-bar-fill {
  height: 100%;
  background: linear-gradient(90deg, #4d9de0, #00d4aa);
  border-radius: var(--radius-full);
}

.ability-tag {
  position: absolute;
  top: 12px;
  right: 14px;
  font-size: 10px;
  font-weight: 600;
  padding: 2px 8px;
  border-radius: var(--radius-full);
}

.tag-strong {
  background: color-mix(in srgb, #00d4aa 15%, transparent);
  color: #00a07d;
}

.tag-weak {
  background: color-mix(in srgb, #ff6b6b 15%, transparent);
  color: #d9483f;
}

/* === 优势/薄弱双栏 === */
.duo-section {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
  margin-bottom: 32px;
}

.duo-card {
  background: var(--color-bg-elevated);
  border: 1px solid var(--color-border-subtle);
  border-radius: var(--radius-lg);
  padding: 18px 20px;
}

.duo-card--strength {
  border-left: 3px solid #00d4aa;
}

.duo-card--weak {
  border-left: 3px solid #ff6b6b;
}

.duo-head {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin-bottom: 12px;
}

.duo-icon {
  font-size: 12px;
}

.duo-card--strength .duo-icon { color: #00d4aa; }
.duo-card--weak .duo-icon { color: #ff6b6b; }

.duo-title {
  font-family: var(--font-serif);
  font-size: 14px;
  font-weight: 700;
  color: var(--color-ink-900);
}

.duo-en {
  font-family: var(--font-mono);
  font-size: 10px;
  color: var(--color-fg-tertiary);
  text-transform: uppercase;
}

.duo-list {
  list-style: none;
  padding: 0;
  margin: 0;
}

.duo-list li {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  padding: 8px 0;
  border-bottom: 1px solid var(--color-border-subtle);
}

.duo-list li:last-child {
  border-bottom: none;
}

.duo-name {
  font-size: 13px;
  font-weight: 500;
  color: var(--color-ink-900);
}

.duo-meta {
  font-family: var(--font-mono);
  font-size: 11px;
  color: var(--color-fg-tertiary);
}

/* === CTA === */
.cta-section {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 20px 24px;
  background: color-mix(in srgb, #4d9de0 6%, var(--color-bg-elevated));
  border: 1px solid color-mix(in srgb, #4d9de0 30%, transparent);
  border-radius: var(--radius-lg);
}

.cta-text {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.cta-title {
  font-family: var(--font-serif);
  font-size: 15px;
  font-weight: 600;
  color: var(--color-ink-900);
}

.cta-sub {
  font-size: 12px;
  color: var(--color-fg-secondary);
}

.cta-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 10px 20px;
  background: #4d9de0;
  color: #fff;
  border: none;
  border-radius: var(--radius-full);
  font-family: var(--font-serif);
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  white-space: nowrap;
}

.cta-btn:hover {
  background: #3a87c4;
  transform: translateX(2px);
}

.cta-arrow {
  font-size: 16px;
}

/* === 旗舰旅程引导 CTA（P0 #8） === */
.journey-cta-section {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 18px 24px;
  margin-top: 16px;
  background: linear-gradient(135deg, color-mix(in srgb, #9b59b6 7%, var(--color-bg-elevated)), color-mix(in srgb, #4d9de0 4%, var(--color-bg-elevated)));
  border: 1px solid color-mix(in srgb, #9b59b6 25%, transparent);
  border-radius: var(--radius-lg);
}

.journey-cta-content {
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.journey-cta-badge {
  font-family: var(--font-mono);
  font-size: 9px;
  font-weight: 700;
  color: #9b59b6;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.journey-cta-title {
  font-family: var(--font-serif);
  font-size: 15px;
  font-weight: 700;
  color: var(--color-ink-900);
}

.journey-cta-desc {
  font-size: 12px;
  color: var(--color-fg-secondary);
}

.journey-cta-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 10px 20px;
  background: #9b59b6;
  color: #fff;
  border: none;
  border-radius: var(--radius-full);
  font-family: var(--font-serif);
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  white-space: nowrap;
}

.journey-cta-btn:hover {
  background: #8e44ad;
  transform: translateX(2px);
}

@media (max-width: 768px) {
  .overview-row { grid-template-columns: 1fr; }
  .duo-section { grid-template-columns: 1fr; }
  .cta-section { flex-direction: column; align-items: flex-start; }
  .journey-cta-section { flex-direction: column; align-items: flex-start; }
}
</style>
